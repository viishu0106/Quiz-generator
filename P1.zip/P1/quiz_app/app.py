"""
app.py
------
Streamlit entry point for the AI Quiz Generator.
Contains only UI rendering logic — all business logic is in other modules.

Run with:
    streamlit run app.py
"""

from __future__ import annotations

import time
from typing import Optional

import streamlit as st

from ai_generator import generate_questions
from models import QuizConfig, QuizState
from storage import save_results
from validator import validate_config

# ---------------------------------------------------------------------------
# Page configuration (must be the first Streamlit call)
# ---------------------------------------------------------------------------

st.set_page_config(
    page_title="AI Quiz Generator",
    page_icon="🧠",
    layout="centered",
)

# ---------------------------------------------------------------------------
# Session-state initialisation
# ---------------------------------------------------------------------------

def _init_session_state() -> None:
    """Ensure all required session-state keys exist."""
    defaults = {
        "phase": "config",          # "config" | "quiz" | "summary"
        "quiz_state": None,         # QuizState object
        "answer_given": False,      # True after the user picks an answer
        "selected_answer": None,    # The answer the user just chose
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


def _reset_quiz() -> None:
    """Clear all quiz-related session state and return to the config screen."""
    for key in ("phase", "quiz_state", "answer_given", "selected_answer"):
        if key in st.session_state:
            del st.session_state[key]
    _init_session_state()


# ---------------------------------------------------------------------------
# Screen: Configuration Form
# ---------------------------------------------------------------------------

def render_config_form() -> None:
    """Display the quiz setup form and handle the Generate button."""
    st.title("🧠 AI Quiz Generator")
    st.markdown(
        "Configure your quiz below, then click **Generate Quiz** to start."
    )

    with st.form("quiz_config_form"):
        topic = st.text_input(
            "Quiz Topic",
            placeholder="e.g. Ancient Rome, Python basics, World Geography …",
            max_chars=100,
        )

        difficulty = st.selectbox(
            "Difficulty",
            options=["Easy", "Medium", "Hard"],
        )

        num_questions = st.slider(
            "Number of Questions",
            min_value=1,
            max_value=20,
            value=5,
        )

        submitted = st.form_submit_button("🚀 Generate Quiz", use_container_width=True)

    if not submitted:
        return

    # ---- Validate ----
    config = QuizConfig(
        topic=topic,
        difficulty=str(difficulty),
        num_questions=int(num_questions),
    )
    errors = validate_config(config)
    if errors:
        for error in errors:
            st.error(error)
        return

    # ---- Generate ----
    with st.spinner("Generating your quiz… this may take a few seconds."):
        questions, used_fallback = generate_questions(config)

    quiz_state = QuizState(
        config=config,
        questions=questions,
        used_fallback=used_fallback,
    )
    st.session_state["quiz_state"] = quiz_state
    st.session_state["phase"] = "quiz"
    st.session_state["answer_given"] = False
    st.session_state["selected_answer"] = None
    st.rerun()


# ---------------------------------------------------------------------------
# Screen: Quiz (one question at a time)
# ---------------------------------------------------------------------------

def render_quiz() -> None:
    """Display the current question and handle answer selection."""
    state: QuizState = st.session_state["quiz_state"]

    # ---- Fallback banner ----
    if state.used_fallback:
        st.info(
            "ℹ️ Using sample questions — AI generation is unavailable. "
            "Add your OpenAI API key to the `.env` file to enable AI questions.",
            icon=None,
        )

    # ---- Progress bar ----
    progress = (state.current_index) / state.total_questions
    st.progress(progress)
    st.markdown(
        f"**Question {state.current_index + 1} of {state.total_questions}** "
        f"&nbsp;|&nbsp; 📊 Score: **{state.score}**"
    )

    question = state.current_question

    # ---- Question card ----
    st.markdown("---")
    st.subheader(question.text)

    # ---- Answer options ----
    # Disable radio buttons once an answer has been given for this question
    answer_already_given = st.session_state["answer_given"]

    selected = st.radio(
        "Choose your answer:",
        options=question.options,
        index=None,
        key=f"q_{state.current_index}",
        disabled=answer_already_given,
    )

    # ---- Submit button ----
    if not answer_already_given:
        if st.button("✅ Submit Answer", disabled=(selected is None), use_container_width=True):
            _handle_answer(state, selected)
            st.rerun()
    else:
        # ---- Feedback ----
        _render_feedback(
            user_answer=st.session_state["selected_answer"],
            correct_answer=question.correct_answer,
        )

        # ---- Advance button ----
        if state.is_last_question:
            if st.button("🏁 See Results", use_container_width=True):
                state.quiz_complete = True
                save_results(state)
                st.session_state["phase"] = "summary"
                st.rerun()
        else:
            if st.button("➡️ Next Question", use_container_width=True):
                state.current_index += 1
                st.session_state["answer_given"] = False
                st.session_state["selected_answer"] = None
                st.rerun()


def _handle_answer(state: QuizState, selected: Optional[str]) -> None:
    """Record the user's answer and update the score."""
    if selected is None:
        return

    state.user_answers.append(selected)
    if selected == state.current_question.correct_answer:
        state.score += 1

    st.session_state["answer_given"] = True
    st.session_state["selected_answer"] = selected


def _render_feedback(user_answer: str, correct_answer: str) -> None:
    """Show green/red feedback and the correct answer."""
    if user_answer == correct_answer:
        st.success(f"✅ Correct!  The answer is **{correct_answer}**.")
    else:
        st.error(
            f"❌ Incorrect.  You chose **{user_answer}**.  "
            f"The correct answer is **{correct_answer}**."
        )


# ---------------------------------------------------------------------------
# Screen: Summary
# ---------------------------------------------------------------------------

def render_summary() -> None:
    """Display the final score and a per-question review table."""
    state: QuizState = st.session_state["quiz_state"]

    st.title("🏆 Quiz Complete!")

    # ---- Score card ----
    col1, col2, col3 = st.columns(3)
    col1.metric("Score", f"{state.score} / {state.total_questions}")
    col2.metric("Correct", state.score)
    col3.metric("Incorrect", state.incorrect_answers)

    st.markdown(f"### {state.score_percentage}% — {_grade_label(state.score_percentage)}")
    st.progress(state.score_percentage / 100)

    # ---- Config recap ----
    st.markdown(
        f"**Topic:** {state.config.topic} &nbsp;|&nbsp; "
        f"**Difficulty:** {state.config.difficulty}"
    )

    if state.used_fallback:
        st.info("ℹ️ These were sample questions (AI was unavailable).")

    # ---- Per-question review ----
    st.markdown("---")
    st.subheader("📋 Question Review")

    for i, question in enumerate(state.questions):
        user_answer = state.user_answers[i] if i < len(state.user_answers) else "—"
        is_correct = user_answer == question.correct_answer
        icon = "✅" if is_correct else "❌"

        with st.expander(f"{icon} Q{i + 1}: {question.text}"):
            st.markdown(f"**Your answer:** {user_answer}")
            st.markdown(f"**Correct answer:** {question.correct_answer}")
            if not is_correct:
                st.markdown(f"**All options:** {', '.join(question.options)}")

    # ---- Restart ----
    st.markdown("---")
    if st.button("🔄 Start a New Quiz", use_container_width=True):
        _reset_quiz()
        st.rerun()


def _grade_label(percentage: float) -> str:
    """Return a simple label based on the score percentage."""
    if percentage >= 90:
        return "Excellent! 🌟"
    if percentage >= 70:
        return "Great job! 👍"
    if percentage >= 50:
        return "Good effort! 💪"
    return "Keep practising! 📚"


# ---------------------------------------------------------------------------
# Main router
# ---------------------------------------------------------------------------

def main() -> None:
    _init_session_state()

    phase = st.session_state["phase"]

    if phase == "config":
        render_config_form()
    elif phase == "quiz":
        render_quiz()
    elif phase == "summary":
        render_summary()
    else:
        # Safety fallback — should never happen
        _reset_quiz()
        st.rerun()


if __name__ == "__main__":
    main()
