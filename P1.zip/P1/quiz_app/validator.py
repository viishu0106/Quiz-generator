"""
validator.py
------------
Pure validation functions for quiz configuration inputs.
Returns error messages as strings; an empty list means everything is valid.
No side effects, no Streamlit imports — fully testable in isolation.
"""

from __future__ import annotations

from typing import List, Optional

from models import QuizConfig

ALLOWED_DIFFICULTIES = ("Easy", "Medium", "Hard")
MIN_QUESTIONS = 1
MAX_QUESTIONS = 20
MAX_TOPIC_LENGTH = 100


def validate_topic(topic: str) -> Optional[str]:
    """
    Return an error message if the topic is invalid, otherwise None.

    Rules:
    - Must not be blank or whitespace-only.
    - Must not exceed MAX_TOPIC_LENGTH characters.
    """
    if not topic or not topic.strip():
        return "Topic cannot be empty."
    if len(topic.strip()) > MAX_TOPIC_LENGTH:
        return f"Topic must be {MAX_TOPIC_LENGTH} characters or fewer."
    return None


def validate_difficulty(difficulty: str) -> Optional[str]:
    """
    Return an error message if the difficulty is invalid, otherwise None.
    Comparison is case-sensitive — must match exactly.
    """
    if difficulty not in ALLOWED_DIFFICULTIES:
        allowed = ", ".join(ALLOWED_DIFFICULTIES)
        return f"Difficulty must be one of: {allowed}."
    return None


def validate_num_questions(num_questions: int) -> Optional[str]:
    """
    Return an error message if the question count is out of range, otherwise None.
    """
    if not isinstance(num_questions, int):
        return "Number of questions must be an integer."
    if num_questions < MIN_QUESTIONS:
        return f"Number of questions must be at least {MIN_QUESTIONS}."
    if num_questions > MAX_QUESTIONS:
        return f"Number of questions cannot exceed {MAX_QUESTIONS}."
    return None


def validate_config(config: QuizConfig) -> List[str]:
    """
    Validate all fields in a QuizConfig.
    Returns a list of error message strings.
    An empty list means the config is fully valid.
    """
    errors: List[str] = []

    topic_error = validate_topic(config.topic)
    if topic_error:
        errors.append(topic_error)

    difficulty_error = validate_difficulty(config.difficulty)
    if difficulty_error:
        errors.append(difficulty_error)

    num_questions_error = validate_num_questions(config.num_questions)
    if num_questions_error:
        errors.append(num_questions_error)

    return errors
