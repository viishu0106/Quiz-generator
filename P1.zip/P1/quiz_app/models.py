"""
models.py
---------
Pure data containers and custom exceptions for the AI Quiz Generator.
No business logic lives here — only dataclasses and exception definitions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


# ---------------------------------------------------------------------------
# Custom Exceptions
# ---------------------------------------------------------------------------

class InvalidConfigError(Exception):
    """Raised when the quiz configuration fails validation."""


class AIGenerationError(Exception):
    """Raised when the OpenAI API call fails for any reason."""


class ParseError(Exception):
    """Raised when the AI response cannot be parsed into Question objects."""


# ---------------------------------------------------------------------------
# Data Classes
# ---------------------------------------------------------------------------

@dataclass
class QuizConfig:
    """Holds the user-supplied settings for a quiz session."""

    topic: str
    difficulty: str          # "Easy" | "Medium" | "Hard"
    num_questions: int


@dataclass
class Question:
    """Represents one multiple-choice question."""

    text: str
    options: List[str]       # Exactly 4 items
    correct_answer: str      # Must match one item in options exactly


@dataclass
class QuizState:
    """
    Tracks all mutable state during an active quiz session.
    Stored in st.session_state so Streamlit reruns don't lose progress.
    """

    config: QuizConfig
    questions: List[Question]
    current_index: int = 0
    score: int = 0
    user_answers: List[str] = field(default_factory=list)
    quiz_complete: bool = False
    used_fallback: bool = False   # True when sample questions were used

    # ------------------------------------------------------------------
    # Convenience helpers (read-only properties, no side effects)
    # ------------------------------------------------------------------

    @property
    def total_questions(self) -> int:
        return len(self.questions)

    @property
    def current_question(self) -> Question:
        return self.questions[self.current_index]

    @property
    def is_last_question(self) -> bool:
        return self.current_index >= self.total_questions - 1

    @property
    def incorrect_answers(self) -> int:
        return len(self.user_answers) - self.score

    @property
    def score_percentage(self) -> float:
        if self.total_questions == 0:
            return 0.0
        return round((self.score / self.total_questions) * 100, 1)
