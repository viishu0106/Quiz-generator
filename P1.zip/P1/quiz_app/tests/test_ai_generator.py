"""
tests/test_ai_generator.py
--------------------------
Unit tests for ai_generator.py.
All OpenAI API calls are mocked — no real API key needed.
"""

import sys
import os
import json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from unittest.mock import patch, MagicMock

import pytest
from ai_generator import build_prompt, parse_response, call_openai, generate_questions
from models import AIGenerationError, ParseError, QuizConfig, Question


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def config() -> QuizConfig:
    return QuizConfig(topic="Ancient Rome", difficulty="Medium", num_questions=2)


def _make_valid_json(n: int = 2) -> str:
    """Return a valid JSON string with n questions."""
    questions = [
        {
            "text": f"Question {i + 1}?",
            "options": ["A", "B", "C", "D"],
            "correct_answer": "A",
        }
        for i in range(n)
    ]
    return json.dumps(questions)


# ---------------------------------------------------------------------------
# build_prompt
# ---------------------------------------------------------------------------

class TestBuildPrompt:
    def test_contains_topic(self, config: QuizConfig):
        prompt = build_prompt(config)
        assert "Ancient Rome" in prompt

    def test_contains_difficulty(self, config: QuizConfig):
        prompt = build_prompt(config)
        assert "Medium" in prompt

    def test_contains_num_questions(self, config: QuizConfig):
        prompt = build_prompt(config)
        assert "2" in prompt

    def test_returns_string(self, config: QuizConfig):
        assert isinstance(build_prompt(config), str)


# ---------------------------------------------------------------------------
# parse_response
# ---------------------------------------------------------------------------

class TestParseResponse:
    def test_valid_json_returns_questions(self):
        raw = _make_valid_json(2)
        questions = parse_response(raw, 2)
        assert len(questions) == 2
        assert all(isinstance(q, Question) for q in questions)

    def test_correct_answer_is_preserved(self):
        raw = json.dumps([
            {"text": "Q?", "options": ["X", "Y", "Z", "W"], "correct_answer": "Z"}
        ])
        questions = parse_response(raw, 1)
        assert questions[0].correct_answer == "Z"

    def test_options_are_preserved(self):
        raw = _make_valid_json(1)
        questions = parse_response(raw, 1)
        assert questions[0].options == ["A", "B", "C", "D"]

    def test_invalid_json_raises_parse_error(self):
        with pytest.raises(ParseError):
            parse_response("not json at all", 1)

    def test_non_array_raises_parse_error(self):
        with pytest.raises(ParseError):
            parse_response('{"text": "Q?"}', 1)

    def test_missing_text_key_raises_parse_error(self):
        bad = json.dumps([{"options": ["A","B","C","D"], "correct_answer": "A"}])
        with pytest.raises(ParseError):
            parse_response(bad, 1)

    def test_missing_options_key_raises_parse_error(self):
        bad = json.dumps([{"text": "Q?", "correct_answer": "A"}])
        with pytest.raises(ParseError):
            parse_response(bad, 1)

    def test_missing_correct_answer_key_raises_parse_error(self):
        bad = json.dumps([{"text": "Q?", "options": ["A","B","C","D"]}])
        with pytest.raises(ParseError):
            parse_response(bad, 1)

    def test_correct_answer_not_in_options_raises_parse_error(self):
        bad = json.dumps([
            {"text": "Q?", "options": ["A","B","C","D"], "correct_answer": "E"}
        ])
        with pytest.raises(ParseError):
            parse_response(bad, 1)

    def test_fewer_than_4_options_raises_parse_error(self):
        bad = json.dumps([
            {"text": "Q?", "options": ["A","B","C"], "correct_answer": "A"}
        ])
        with pytest.raises(ParseError):
            parse_response(bad, 1)

    def test_fewer_questions_than_requested_raises_parse_error(self):
        raw = _make_valid_json(1)
        with pytest.raises(ParseError):
            parse_response(raw, 3)

    def test_extra_questions_are_trimmed(self):
        raw = _make_valid_json(5)
        questions = parse_response(raw, 3)
        assert len(questions) == 3


# ---------------------------------------------------------------------------
# call_openai
# ---------------------------------------------------------------------------

class TestCallOpenai:
    def test_raises_when_api_key_missing(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": ""}, clear=False):
            with pytest.raises(AIGenerationError):
                call_openai("some prompt")

    def test_raises_when_api_key_is_placeholder(self):
        with patch.dict(os.environ, {"OPENAI_API_KEY": "your-api-key-here"}):
            with pytest.raises(AIGenerationError):
                call_openai("some prompt")

    def test_returns_content_on_success(self):
        mock_response = MagicMock()
        mock_response.choices[0].message.content = '["answer"]'

        with patch.dict(os.environ, {"OPENAI_API_KEY": "sk-test"}):
            with patch("openai.OpenAI") as mock_openai_cls:
                mock_openai_cls.return_value.chat.completions.create.return_value = mock_response
                result = call_openai("prompt")

        assert result == '["answer"]'


# ---------------------------------------------------------------------------
# generate_questions (integration — mocked OpenAI)
# ---------------------------------------------------------------------------

class TestGenerateQuestions:
    def test_returns_questions_on_success(self, config: QuizConfig):
        valid_json = _make_valid_json(config.num_questions)

        with patch("ai_generator.call_openai", return_value=valid_json):
            questions, used_fallback = generate_questions(config)

        assert len(questions) == config.num_questions
        assert used_fallback is False

    def test_falls_back_when_api_raises(self, config: QuizConfig):
        with patch("ai_generator.call_openai", side_effect=AIGenerationError("no key")):
            questions, used_fallback = generate_questions(config)

        assert len(questions) == config.num_questions
        assert used_fallback is True

    def test_falls_back_when_parse_fails(self, config: QuizConfig):
        with patch("ai_generator.call_openai", return_value="bad json"):
            questions, used_fallback = generate_questions(config)

        assert used_fallback is True
        assert len(questions) > 0

    def test_returns_tuple_of_two(self, config: QuizConfig):
        with patch("ai_generator.call_openai", return_value=_make_valid_json(2)):
            result = generate_questions(config)

        assert isinstance(result, tuple)
        assert len(result) == 2
