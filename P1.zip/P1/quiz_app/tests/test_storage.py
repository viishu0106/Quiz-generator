"""
tests/test_storage.py
---------------------
Unit tests for storage.py — save and load quiz results to/from JSON.
Uses a temporary file so tests don't pollute the real results.json.
"""

import sys
import os
import json
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from unittest.mock import patch

import storage
from models import QuizConfig, Question, QuizState


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_state(score: int = 2) -> QuizState:
    config = QuizConfig(topic="Science", difficulty="Easy", num_questions=3)
    questions = [
        Question(
            text=f"Question {i + 1}?",
            options=["A", "B", "C", "D"],
            correct_answer="A",
        )
        for i in range(3)
    ]
    state = QuizState(
        config=config,
        questions=questions,
        score=score,
        user_answers=["A", "B", "A"],
        quiz_complete=True,
    )
    return state


# ---------------------------------------------------------------------------
# save_results
# ---------------------------------------------------------------------------

class TestSaveResults:
    def test_creates_file(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
        assert os.path.exists(results_file)

    def test_file_is_valid_json(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
        with open(results_file) as f:
            data = json.load(f)
        assert isinstance(data, dict)

    def test_correct_top_level_keys(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
        with open(results_file) as f:
            data = json.load(f)
        for key in ("topic", "difficulty", "score", "total", "questions"):
            assert key in data

    def test_score_is_correct(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state(score=2))
        with open(results_file) as f:
            data = json.load(f)
        assert data["score"] == 2

    def test_questions_list_length_matches(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
        with open(results_file) as f:
            data = json.load(f)
        assert len(data["questions"]) == 3

    def test_user_answer_is_recorded(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
        with open(results_file) as f:
            data = json.load(f)
        assert data["questions"][0]["user_answer"] == "A"

    def test_is_correct_flag_is_set(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
        with open(results_file) as f:
            data = json.load(f)
        # question 0: user answered "A", correct is "A" → True
        assert data["questions"][0]["is_correct"] is True
        # question 1: user answered "B", correct is "A" → False
        assert data["questions"][1]["is_correct"] is False

    def test_second_save_overwrites_first(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state(score=1))
            storage.save_results(_make_state(score=3))
        with open(results_file) as f:
            data = json.load(f)
        assert data["score"] == 3


# ---------------------------------------------------------------------------
# load_results
# ---------------------------------------------------------------------------

class TestLoadResults:
    def test_returns_none_when_file_missing(self, tmp_path):
        missing_file = str(tmp_path / "no_file.json")
        with patch.object(storage, "RESULTS_FILE", missing_file):
            result = storage.load_results()
        assert result is None

    def test_returns_dict_after_save(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
            result = storage.load_results()
        assert isinstance(result, dict)

    def test_loaded_topic_matches_saved(self, tmp_path):
        results_file = str(tmp_path / "results.json")
        with patch.object(storage, "RESULTS_FILE", results_file):
            storage.save_results(_make_state())
            result = storage.load_results()
        assert result["topic"] == "Science"
