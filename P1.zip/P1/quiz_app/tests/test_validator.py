"""
tests/test_validator.py
-----------------------
Unit tests for validator.py — covers valid and invalid inputs for all three
validation functions, plus the combined validate_config helper.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest
from validator import (
    validate_topic,
    validate_difficulty,
    validate_num_questions,
    validate_config,
    MAX_TOPIC_LENGTH,
    MIN_QUESTIONS,
    MAX_QUESTIONS,
)
from models import QuizConfig


# ---------------------------------------------------------------------------
# validate_topic
# ---------------------------------------------------------------------------

class TestValidateTopic:
    def test_valid_topic_returns_none(self):
        assert validate_topic("World War II") is None

    def test_empty_string_returns_error(self):
        assert validate_topic("") is not None

    def test_whitespace_only_returns_error(self):
        assert validate_topic("   ") is not None

    def test_topic_at_max_length_is_valid(self):
        topic = "a" * MAX_TOPIC_LENGTH
        assert validate_topic(topic) is None

    def test_topic_over_max_length_returns_error(self):
        topic = "a" * (MAX_TOPIC_LENGTH + 1)
        assert validate_topic(topic) is not None

    def test_topic_with_leading_trailing_spaces_is_valid(self):
        assert validate_topic("  Python  ") is None


# ---------------------------------------------------------------------------
# validate_difficulty
# ---------------------------------------------------------------------------

class TestValidateDifficulty:
    def test_easy_is_valid(self):
        assert validate_difficulty("Easy") is None

    def test_medium_is_valid(self):
        assert validate_difficulty("Medium") is None

    def test_hard_is_valid(self):
        assert validate_difficulty("Hard") is None

    def test_lowercase_easy_returns_error(self):
        assert validate_difficulty("easy") is not None

    def test_uppercase_easy_returns_error(self):
        assert validate_difficulty("EASY") is not None

    def test_unknown_value_returns_error(self):
        assert validate_difficulty("Extreme") is not None

    def test_empty_string_returns_error(self):
        assert validate_difficulty("") is not None


# ---------------------------------------------------------------------------
# validate_num_questions
# ---------------------------------------------------------------------------

class TestValidateNumQuestions:
    def test_min_questions_is_valid(self):
        assert validate_num_questions(MIN_QUESTIONS) is None

    def test_max_questions_is_valid(self):
        assert validate_num_questions(MAX_QUESTIONS) is None

    def test_middle_value_is_valid(self):
        assert validate_num_questions(10) is None

    def test_zero_returns_error(self):
        assert validate_num_questions(0) is not None

    def test_negative_returns_error(self):
        assert validate_num_questions(-1) is not None

    def test_over_max_returns_error(self):
        assert validate_num_questions(MAX_QUESTIONS + 1) is not None

    def test_non_integer_returns_error(self):
        assert validate_num_questions(5.5) is not None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# validate_config
# ---------------------------------------------------------------------------

class TestValidateConfig:
    def _valid_config(self) -> QuizConfig:
        return QuizConfig(topic="History", difficulty="Medium", num_questions=5)

    def test_valid_config_returns_empty_list(self):
        assert validate_config(self._valid_config()) == []

    def test_blank_topic_produces_one_error(self):
        cfg = QuizConfig(topic="", difficulty="Easy", num_questions=5)
        errors = validate_config(cfg)
        assert len(errors) == 1

    def test_invalid_difficulty_produces_one_error(self):
        cfg = QuizConfig(topic="Science", difficulty="Impossible", num_questions=5)
        errors = validate_config(cfg)
        assert len(errors) == 1

    def test_invalid_num_questions_produces_one_error(self):
        cfg = QuizConfig(topic="Science", difficulty="Easy", num_questions=0)
        errors = validate_config(cfg)
        assert len(errors) == 1

    def test_two_invalid_fields_produce_two_errors(self):
        cfg = QuizConfig(topic="", difficulty="Bad", num_questions=5)
        errors = validate_config(cfg)
        assert len(errors) == 2

    def test_all_invalid_fields_produce_three_errors(self):
        cfg = QuizConfig(topic="", difficulty="Bad", num_questions=0)
        errors = validate_config(cfg)
        assert len(errors) == 3
