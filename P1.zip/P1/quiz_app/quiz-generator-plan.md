# AI Quiz Generator — Implementation Plan

## Top-Level Overview

Build a small, beginner-friendly AI-powered quiz app using Python and Streamlit.
The user enters a topic, picks a difficulty and question count, and the app calls the
OpenAI API (GPT-4o / GPT-3.5-turbo) to generate multiple-choice questions.
Questions are shown one at a time; selecting an answer auto-advances to the next
question after feedback is shown. A final summary screen displays the score and a
per-question review. Results are saved to `results.json` (latest quiz only).

When the OpenAI API key is unavailable, a small hardcoded bank of sample questions
is used so the app still runs without any external dependency.

---

## Project Structure

```
quiz_app/
├── app.py              ← Streamlit entry point — UI rendering and session control
├── models.py           ← QuizConfig, Question, QuizState dataclasses
├── ai_generator.py     ← OpenAI call, prompt building, response parsing, fallback
├── validator.py        ← Input validation functions
├── storage.py          ← Save/load results.json
├── sample_questions.py ← Hardcoded fallback question bank
├── requirements.txt    ← streamlit, openai, python-dotenv
├── .env                ← OPENAI_API_KEY (never committed to git)
├── results.json        ← Written at end of each quiz (overwritten each time)
└── tests/
    ├── test_validator.py
    ├── test_ai_generator.py
    ├── test_models.py
    └── test_storage.py
```

---

## Classes and Their Responsibilities

### `QuizConfig` (in `models.py`)
A plain dataclass that holds the user's quiz settings.

| Field          | Type  | Description                              |
|----------------|-------|------------------------------------------|
| `topic`        | str   | The quiz subject entered by the user     |
| `difficulty`   | str   | "Easy", "Medium", or "Hard"              |
| `num_questions`| int   | How many questions to generate (1–20)    |

### `Question` (in `models.py`)
Represents one multiple-choice question returned by the AI (or fallback bank).

| Field            | Type       | Description                              |
|------------------|------------|------------------------------------------|
| `text`           | str        | The question text                        |
| `options`        | list[str]  | Exactly 4 answer choices                 |
| `correct_answer` | str        | Must match one item in `options` exactly |

### `QuizState` (in `models.py`)
Tracks everything that changes while the user is answering questions.
This is what gets stored in Streamlit's `st.session_state`.

| Field           | Type            | Description                                  |
|-----------------|-----------------|----------------------------------------------|
| `questions`     | list[Question]  | All generated questions for this quiz        |
| `current_index` | int             | Which question is currently shown (0-based)  |
| `score`         | int             | Number of correct answers so far             |
| `user_answers`  | list[str]       | The user's selected answer for each question |
| `quiz_complete` | bool            | True once the last question is answered      |
| `config`        | QuizConfig      | The settings used to generate this quiz      |

---

## Modules and Their Responsibilities

### `models.py`
Define `QuizConfig`, `Question`, and `QuizState` as Python `@dataclass` objects.
No logic here — pure data containers.

### `ai_generator.py`
Owns all AI interaction. Three focused functions:

- **`build_prompt(config)`** — constructs the text prompt that asks the AI for
  questions in a strict JSON format.
- **`call_openai(prompt)`** — sends the prompt to the OpenAI API and returns raw text.
  Raises `AIGenerationError` on any API failure.
- **`parse_response(raw_text, num_questions)`** — parses the JSON from the AI's
  response into a list of `Question` objects. Raises `ParseError` if the response
  does not match the expected shape.
- **`generate_questions(config)`** — orchestrates the above three functions.
  If the API key is missing or any error occurs, it falls back to
  `sample_questions.py` and returns questions from there instead.

### `sample_questions.py`
A plain Python file that holds a small hardcoded list of `Question` objects across
a few topics (e.g. general knowledge, Python basics, geography). Used only when the
OpenAI API is unavailable.

### `validator.py`
Pure functions — no classes, no side effects.

- **`validate_topic(topic)`** — returns an error string if blank/whitespace or
  over 100 characters, otherwise returns None.
- **`validate_difficulty(difficulty)`** — checks it is one of the three allowed values.
- **`validate_num_questions(n)`** — checks it is an integer between 1 and 20.
- **`validate_config(config)`** — calls all three above and returns a list of
  error messages (empty list means valid).

### `storage.py`
Two simple functions:

- **`save_results(state)`** — serialises the completed `QuizState` to
  `results.json` (overwrites any previous file).
- **`load_results()`** — reads and returns the contents of `results.json`, or
  None if the file does not exist.

### `app.py`
Streamlit UI only — no business logic. Calls into the other modules and manages
`st.session_state`. Contains rendering functions:

- **`render_config_form()`** — shows topic input, difficulty selector, question count slider, and Generate button.
- **`render_question()`** — shows the current question text and four radio buttons (one per option).
- **`render_feedback(is_correct, correct_answer)`** — shows a green check or red X and the correct answer text.
- **`render_summary()`** — shows final score, percentage, and a table of every question with the user's answer vs the correct answer.
- **`reset_quiz()`** — clears all quiz-related keys from `st.session_state`.

---

## Data Flow

```
User fills config form
        │
        ▼
validate_config(config)  ──► show errors if invalid
        │ valid
        ▼
generate_questions(config)
  ├── try: build_prompt → call_openai → parse_response → list[Question]
  └── except: load from sample_questions
        │
        ▼
QuizState stored in st.session_state
        │
        ▼
render_question()  ◄──────────────────────────┐
        │ user selects answer                  │
        ▼                                      │
handle_answer(selected, question)              │
  ├── compare to correct_answer               │
  ├── update score and user_answers           │
  └── render_feedback() ── short pause ───────┘
        │ last question answered
        ▼
save_results(state) → results.json
        │
        ▼
render_summary()
        │ user clicks Restart
        ▼
reset_quiz() → back to config form
```

---

## State Management in Streamlit

Streamlit reruns the entire script on every interaction. All mutable state must
live in `st.session_state`.

Keys stored in `st.session_state`:

| Key              | Type       | Set when                              |
|------------------|------------|---------------------------------------|
| `quiz_state`     | QuizState  | After questions are generated         |
| `phase`          | str        | "config", "quiz", or "summary"        |
| `answer_given`   | bool       | True immediately after answer chosen  |
| `feedback_shown` | bool       | True once feedback render is complete |

**Phase transitions:**

- `"config"` → `"quiz"` : user clicks Generate and validation passes
- `"quiz"` → `"summary"` : last question is answered
- `"summary"` → `"config"` : user clicks Restart

The `phase` key controls which render function `app.py` calls. No logic leaks
between phases.

---

## AI Question-Generation Approach

### Prompt Design
The prompt instructs the model to return a JSON array. Each element is an object
with three keys: `"text"`, `"options"` (array of 4 strings), and `"correct_answer"`
(a string matching one of the options exactly).

The prompt includes the topic, difficulty, and number of questions. It explicitly
forbids any prose outside the JSON block so parsing is reliable.

### Response Parsing
`parse_response` uses Python's `json.loads()`. It validates:
- The response is a JSON array.
- Each element has the three required keys.
- `options` has exactly 4 items.
- `correct_answer` is present in `options`.

Any failure raises `ParseError`.

### Fallback Strategy
`generate_questions` wraps the OpenAI path in a `try/except`. On any failure
(missing API key, network error, parse error, wrong question count) it silently
falls back to `sample_questions.py`. The UI shows a small informational banner:
"Using sample questions — AI generation unavailable."

---

## JSON Persistence Approach

At the end of every completed quiz, `save_results(state)` writes `results.json`
to the project root. The file is a single JSON object:

```
{
  "topic": "...",
  "difficulty": "...",
  "score": 7,
  "total": 10,
  "questions": [
    {
      "text": "...",
      "options": [...],
      "correct_answer": "...",
      "user_answer": "..."
    },
    ...
  ]
}
```

The file is overwritten each time — no history is accumulated. This is intentional
to keep the implementation simple.

---

## Input Validation Approach

Validation lives entirely in `validator.py` and returns error strings rather than
raising exceptions. The UI calls `validate_config` and renders each error message
using `st.error()` before proceeding.

| Input           | Rule                                           |
|-----------------|------------------------------------------------|
| `topic`         | Not blank/whitespace; max 100 characters       |
| `difficulty`    | Exactly one of "Easy", "Medium", "Hard"        |
| `num_questions` | Integer between 1 and 20 inclusive             |

Streamlit widgets (sliders, selectboxes) enforce most of these automatically.
Written validation still exists so tests can cover it independently of the UI.

---

## Error-Handling Approach

Three custom exception classes defined in `models.py`:

| Exception                  | Raised by           | Meaning                                      |
|----------------------------|---------------------|----------------------------------------------|
| `InvalidConfigError`       | `validator.py`      | Config fails one or more validation rules    |
| `AIGenerationError`        | `ai_generator.py`   | OpenAI API call failed                       |
| `ParseError`               | `ai_generator.py`   | AI response could not be parsed into questions |

In `app.py`, all calls to `generate_questions` are wrapped in `try/except`.
Any unrecoverable error shows `st.error("Something went wrong — please try again.")`.
The fallback in `generate_questions` means the UI almost never has to show an error
for generation failures.

---

## Step-by-Step Implementation Order

Each step should be completed and manually verified before moving to the next.

### Step 1 — Project scaffold
- Create the folder structure and empty files.
- Create `requirements.txt` with: `streamlit`, `openai`, `python-dotenv`.
- Create `.env` with a placeholder `OPENAI_API_KEY=`.
- Create `.gitignore` that excludes `.env` and `results.json`.
- **Done when:** all files exist and `pip install -r requirements.txt` succeeds.

### Step 2 — `models.py`
- Define `QuizConfig`, `Question`, `QuizState` as `@dataclass` classes.
- Define `InvalidConfigError`, `AIGenerationError`, `ParseError` as simple
  exception classes that extend `Exception`.
- **Done when:** importing `models.py` in a Python shell works with no errors.

### Step 3 — `sample_questions.py`
- Write a hardcoded list of at least 10 `Question` objects on 2–3 varied topics.
- The list must cover all difficulty levels so fallback works regardless of config.
- **Done when:** importing the file and printing the list produces valid questions.

### Step 4 — `validator.py`
- Implement `validate_topic`, `validate_difficulty`, `validate_num_questions`,
  and `validate_config`.
- Write `tests/test_validator.py` covering valid and invalid inputs.
- **Done when:** all validator tests pass with `pytest`.

### Step 5 — `ai_generator.py`
- Implement `build_prompt`, `parse_response`, `call_openai`, and `generate_questions`.
- `generate_questions` must fall back to sample questions on any failure.
- Write `tests/test_ai_generator.py` using `unittest.mock.patch` to simulate
  OpenAI responses without a real API key.
- **Done when:** tests pass and manual test with a real API key returns valid questions.

### Step 6 — `storage.py`
- Implement `save_results` and `load_results`.
- Write `tests/test_storage.py` that saves a mock state and reads it back.
- **Done when:** tests pass and `results.json` is created correctly.

### Step 7 — `app.py` — config screen
- Build just the config form: topic input, difficulty select, question count slider,
  Generate button.
- Wire up `validate_config` and call `generate_questions`.
- Store the returned questions in `st.session_state` and set `phase = "quiz"`.
- **Done when:** `streamlit run app.py` shows the form and transitions to the quiz phase.

### Step 8 — `app.py` — quiz screen
- Build `render_question` with radio buttons.
- On selection, call `handle_answer`, show feedback, update score and index.
- After the last question, set `phase = "summary"`.
- **Done when:** full quiz flow works end-to-end in the browser.

### Step 9 — `app.py` — summary screen
- Build `render_summary` showing score, percentage, and per-question review table.
- Call `save_results` before rendering.
- Add a Restart button that calls `reset_quiz()` and sets `phase = "config"`.
- **Done when:** summary screen renders, `results.json` is written, and Restart returns to the form.

### Step 10 — Polish
- Add the "Using sample questions" info banner when fallback is active.
- Handle zero-division gracefully if `num_questions = 0` somehow slips through.
- Test on edge cases: 1 question, 20 questions, blank topic attempt, bad API key.

---

## Testing Plan

All tests live in `tests/` and use `pytest`. No Streamlit UI testing is included —
UI logic is kept thin so the underlying functions can be tested directly.

### `tests/test_models.py`
- Verify `QuizConfig`, `Question`, and `QuizState` can be instantiated with valid data.
- Verify that the custom exceptions can be raised and caught.

### `tests/test_validator.py`
- `validate_topic`: blank string → error; whitespace-only → error; 101 chars → error; valid string → None.
- `validate_difficulty`: "Easy" → None; "EASY" → error; "Hard" → None; "Extreme" → error.
- `validate_num_questions`: 0 → error; 1 → None; 20 → None; 21 → error.
- `validate_config`: all-valid config → empty list; one invalid field → one error in list.

### `tests/test_ai_generator.py`
- `build_prompt`: returns a string containing the topic, difficulty, and question count.
- `parse_response`: valid JSON array → list of `Question` objects.
- `parse_response`: missing `correct_answer` key → raises `ParseError`.
- `parse_response`: `correct_answer` not in `options` → raises `ParseError`.
- `parse_response`: fewer than 3 options → raises `ParseError`.
- `generate_questions` with mocked `call_openai` returning valid JSON → returns questions.
- `generate_questions` with mocked `call_openai` raising exception → returns sample questions.

### `tests/test_storage.py`
- `save_results`: creates `results.json` with correct keys and values.
- `save_results`: calling it twice overwrites the file (only last result remains).
- `load_results`: returns `None` when file does not exist.
- `load_results`: returns correct dict after a `save_results` call.

---

## Non-Goals (Explicitly Out of Scope)

- User accounts or authentication
- Multiple simultaneous users
- Timer per question
- True/False questions
- Question deduplication
- Accumulating quiz history (results.json is overwritten each run)
- Deployment (Streamlit Cloud, Docker, etc.)
