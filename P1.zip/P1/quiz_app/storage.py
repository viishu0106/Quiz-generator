"""
storage.py
----------
Simple JSON persistence for quiz results.
Saves the completed quiz state to results.json (overwrites on each save).
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List, Optional

from models import QuizState

RESULTS_FILE = os.path.join(os.path.dirname(__file__), "results.json")


def save_results(state: QuizState) -> None:
    """
    Serialise the completed QuizState to results.json.
    Overwrites any previous file — only the latest quiz is kept.
    """
    questions_data: List[Dict[str, Any]] = []

    for i, question in enumerate(state.questions):
        user_answer = state.user_answers[i] if i < len(state.user_answers) else ""
        questions_data.append(
            {
                "text": question.text,
                "options": question.options,
                "correct_answer": question.correct_answer,
                "user_answer": user_answer,
                "is_correct": user_answer == question.correct_answer,
            }
        )

    payload: Dict[str, Any] = {
        "topic": state.config.topic,
        "difficulty": state.config.difficulty,
        "score": state.score,
        "total": state.total_questions,
        "score_percentage": state.score_percentage,
        "used_fallback": state.used_fallback,
        "questions": questions_data,
    }

    with open(RESULTS_FILE, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def load_results() -> Optional[Dict[str, Any]]:
    """
    Load the most recent quiz results from results.json.
    Returns None if the file does not exist.
    """
    if not os.path.exists(RESULTS_FILE):
        return None

    with open(RESULTS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)
