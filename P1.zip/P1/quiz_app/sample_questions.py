"""
sample_questions.py
-------------------
Hardcoded fallback questions used when the OpenAI API is unavailable.
Covers three topics across all difficulty levels so the app always works
even without an API key.
"""

from __future__ import annotations

from typing import List

from models import Question


# ---------------------------------------------------------------------------
# General Knowledge
# ---------------------------------------------------------------------------

GENERAL_KNOWLEDGE: List[Question] = [
    Question(
        text="What is the capital city of France?",
        options=["Berlin", "Madrid", "Paris", "Rome"],
        correct_answer="Paris",
    ),
    Question(
        text="Which planet is known as the Red Planet?",
        options=["Venus", "Mars", "Jupiter", "Saturn"],
        correct_answer="Mars",
    ),
    Question(
        text="How many continents are there on Earth?",
        options=["5", "6", "7", "8"],
        correct_answer="7",
    ),
    Question(
        text="What is the largest ocean on Earth?",
        options=["Atlantic Ocean", "Indian Ocean", "Arctic Ocean", "Pacific Ocean"],
        correct_answer="Pacific Ocean",
    ),
    Question(
        text="Which country invented the telephone?",
        options=["United Kingdom", "United States", "Germany", "Canada"],
        correct_answer="United States",
    ),
]

# ---------------------------------------------------------------------------
# Python Basics
# ---------------------------------------------------------------------------

PYTHON_BASICS: List[Question] = [
    Question(
        text="Which keyword is used to define a function in Python?",
        options=["func", "define", "def", "function"],
        correct_answer="def",
    ),
    Question(
        text="What does the `len()` function return?",
        options=[
            "The last element of a list",
            "The number of items in an object",
            "The memory size of an object",
            "The type of an object",
        ],
        correct_answer="The number of items in an object",
    ),
    Question(
        text="Which of the following is a mutable data type in Python?",
        options=["tuple", "str", "int", "list"],
        correct_answer="list",
    ),
    Question(
        text="What symbol is used to start a comment in Python?",
        options=["//", "/*", "#", "--"],
        correct_answer="#",
    ),
    Question(
        text="What will `type(3.14)` return in Python?",
        options=["<class 'int'>", "<class 'float'>", "<class 'str'>", "<class 'number'>"],
        correct_answer="<class 'float'>",
    ),
]

# ---------------------------------------------------------------------------
# World History
# ---------------------------------------------------------------------------

WORLD_HISTORY: List[Question] = [
    Question(
        text="In which year did World War II end?",
        options=["1943", "1944", "1945", "1946"],
        correct_answer="1945",
    ),
    Question(
        text="Who was the first person to walk on the Moon?",
        options=["Buzz Aldrin", "Yuri Gagarin", "Neil Armstrong", "John Glenn"],
        correct_answer="Neil Armstrong",
    ),
    Question(
        text="Which ancient wonder was located in Alexandria, Egypt?",
        options=[
            "The Colossus of Rhodes",
            "The Lighthouse of Alexandria",
            "The Hanging Gardens",
            "The Statue of Zeus",
        ],
        correct_answer="The Lighthouse of Alexandria",
    ),
    Question(
        text="What empire was ruled by Julius Caesar?",
        options=["Greek Empire", "Ottoman Empire", "Roman Empire", "Byzantine Empire"],
        correct_answer="Roman Empire",
    ),
    Question(
        text="The Berlin Wall fell in which year?",
        options=["1987", "1988", "1989", "1990"],
        correct_answer="1989",
    ),
]

# ---------------------------------------------------------------------------
# Combined bank — default pool used for fallback
# ---------------------------------------------------------------------------

ALL_SAMPLE_QUESTIONS: List[Question] = (
    GENERAL_KNOWLEDGE + PYTHON_BASICS + WORLD_HISTORY
)


def get_sample_questions(num_questions: int) -> List[Question]:
    """
    Return up to *num_questions* questions from the sample bank.
    Cycles through the full pool if more questions are requested than exist.
    Never raises — always returns something.
    """
    if num_questions <= 0:
        return []

    pool = ALL_SAMPLE_QUESTIONS
    result: List[Question] = []

    while len(result) < num_questions:
        remaining = num_questions - len(result)
        result.extend(pool[:remaining])

    return result
