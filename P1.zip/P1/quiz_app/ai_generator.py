"""
ai_generator.py
---------------
Handles all communication with the OpenAI API and parsing of its response.
Falls back to sample questions when the API is unavailable or returns an error.

Public API:
    generate_questions(config: QuizConfig) -> List[Question]
"""

from __future__ import annotations

import json
import os
from typing import Any, Dict, List

from dotenv import load_dotenv

from models import AIGenerationError, ParseError, QuizConfig, Question
from sample_questions import get_sample_questions

load_dotenv()

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_OPENAI_MODEL = "gpt-3.5-turbo"
_SYSTEM_PROMPT = (
    "You are a quiz question generator. "
    "Always respond with valid JSON only — no prose, no markdown fences."
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def build_prompt(config: QuizConfig) -> str:
    """
    Construct the user message sent to the OpenAI API.
    Instructs the model to return a strict JSON array of question objects.
    """
    return (
        f"Generate {config.num_questions} multiple-choice quiz questions "
        f"about the topic '{config.topic}' at {config.difficulty} difficulty.\n\n"
        "Return ONLY a JSON array. Each element must be an object with exactly "
        "these three keys:\n"
        '  "text"           : the question text (string)\n'
        '  "options"        : an array of exactly 4 answer choices (strings)\n'
        '  "correct_answer" : the correct answer (must match one of the options exactly)\n\n'
        "Example of the required format:\n"
        "[\n"
        '  {\n'
        '    "text": "What is the capital of France?",\n'
        '    "options": ["Berlin", "Madrid", "Paris", "Rome"],\n'
        '    "correct_answer": "Paris"\n'
        "  }\n"
        "]\n\n"
        "Do NOT include any text outside the JSON array."
    )


def parse_response(raw_text: str, num_questions: int) -> List[Question]:
    """
    Parse the raw text returned by the OpenAI API into Question objects.

    Raises:
        ParseError: if the text is not valid JSON, not an array, or any element
                    is missing required keys / has the wrong shape.
    """
    try:
        data: Any = json.loads(raw_text.strip())
    except json.JSONDecodeError as exc:
        raise ParseError(f"Response is not valid JSON: {exc}") from exc

    if not isinstance(data, list):
        raise ParseError("Expected a JSON array at the top level.")

    questions: List[Question] = []

    for i, item in enumerate(data):
        if not isinstance(item, dict):
            raise ParseError(f"Item {i} is not an object.")

        for key in ("text", "options", "correct_answer"):
            if key not in item:
                raise ParseError(f"Item {i} is missing the '{key}' key.")

        if not isinstance(item["options"], list) or len(item["options"]) != 4:
            raise ParseError(f"Item {i} must have exactly 4 options.")

        if item["correct_answer"] not in item["options"]:
            raise ParseError(
                f"Item {i}: correct_answer '{item['correct_answer']}' "
                "is not in the options list."
            )

        questions.append(
            Question(
                text=str(item["text"]),
                options=[str(o) for o in item["options"]],
                correct_answer=str(item["correct_answer"]),
            )
        )

    if len(questions) < num_questions:
        raise ParseError(
            f"Expected {num_questions} questions but only received {len(questions)}."
        )

    return questions[:num_questions]


def call_openai(prompt: str) -> str:
    """
    Send the prompt to the OpenAI API and return the assistant's raw text.

    Raises:
        AIGenerationError: on any API or network failure.
    """
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key or api_key == "your-api-key-here":
        raise AIGenerationError("OPENAI_API_KEY is not set or is a placeholder.")

    try:
        import openai  # local import so the module loads without openai installed

        client = openai.OpenAI(api_key=api_key)
        response = client.chat.completions.create(
            model=_OPENAI_MODEL,
            messages=[
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.7,
        )
        return response.choices[0].message.content or ""
    except Exception as exc:
        raise AIGenerationError(f"OpenAI API call failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Public interface
# ---------------------------------------------------------------------------

def generate_questions(config: QuizConfig) -> tuple[List[Question], bool]:
    """
    Generate quiz questions for the given config.

    Returns:
        (questions, used_fallback)
        - questions    : list of Question objects
        - used_fallback: True if the sample bank was used instead of the AI
    """
    try:
        prompt = build_prompt(config)
        raw_text = call_openai(prompt)
        questions = parse_response(raw_text, config.num_questions)
        return questions, False
    except (AIGenerationError, ParseError):
        # Silently fall back to the hardcoded sample bank
        fallback = get_sample_questions(config.num_questions)
        return fallback, True
